﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using StraveServices.Helpers;
using StraveServices.Models;

namespace StraveServices.Controllers
{

    [ApiController]
    public class UploadController : ControllerBase
    {
        
        IStravaSessionHelper _stravaSessionHelper;
        ICalculationHelper _calculationHelper;

        public UploadController(IStravaSessionHelper stravaSessionHelper, ICalculationHelper calculationHelper)
        {
            _stravaSessionHelper = stravaSessionHelper;
            _calculationHelper = calculationHelper;
        }

        
        [EnableCors("AllowAll")]
        [HttpPost]       
        [Route("api/UploadActivity")]        
        public IActionResult UploadActivity()
        {
            if (!_stravaSessionHelper.IsAuthenticated())
            {
                return GetNotAuthorizedJsonResult();
            }
            // check if file is TCX format. 
            var file = Request.Form.Files[0];
            var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
            if (  !(new[] { ".tcx" }.Contains(Path.GetExtension(fileName).ToLower())))
            {
                return new JsonResult(new UploadFileResponse { ErrorMessage = "Extension not supported" });
            }
            // need to use using, connections can be left open this will close them when done.
            using (var fileStream = file.OpenReadStream())
            {
                var result = _stravaSessionHelper.GetAuthenticatedApiClient().UploadFile(fileStream, fileName);
                if (!result)
                {
                    return new JsonResult(new UploadFileResponse { ErrorMessage = "Unknown error" });
                }

                return new JsonResult(new UploadFileResponse { IsSuccess = true });
            }
        }

        private JsonResult GetNotAuthorizedJsonResult(bool setStatusCode = true)
        {
            HttpContext.Response.StatusCode = Microsoft.AspNetCore.Http.StatusCodes.Status401Unauthorized;
            return new JsonResult(new UploadFileResponse { ErrorMessage = "Not authorized" });
        }


    }
}
