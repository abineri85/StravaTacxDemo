﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StraveServices.Helpers;
using StraveServices.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StraveServices.Controllers
{
    [ApiController]
    public class CalculationController: ControllerBase
    {
        IStravaSessionHelper _stravaSessionHelper;
        ICalculationHelper _calculationHelper;
        // dependency injection, registered on startup
        public CalculationController(IStravaSessionHelper stravaSessionHelper, ICalculationHelper calculationHelper)
        {
            _stravaSessionHelper = stravaSessionHelper;
            _calculationHelper = calculationHelper;
        }

        [HttpGet]
        [Route("api/GetAllActivities")]
        public IActionResult GetAllActivities()
        {
            if (!_stravaSessionHelper.IsAuthenticated()) // < this can be done via custom annotation
            {
                return GetNotAuthorizedJsonResult();
            }

            var activitiesFromApi = _stravaSessionHelper.GetAuthenticatedApiClient().GetActivities();

            var statsFromData = _calculationHelper.PerformCalculations(activitiesFromApi);

            // map activites to as little properties you need 
            return new JsonResult(new ActivityReturnData { Activities = activitiesFromApi, Stats= statsFromData});
        }

        // this could be seperated into interface. Time limitations
        private JsonResult GetNotAuthorizedJsonResult(bool setStatusCode = true)
        {
            HttpContext.Response.StatusCode = StatusCodes.Status401Unauthorized;
            return new JsonResult(new UploadFileResponse { ErrorMessage = "Not authorized" });
        }
    }
}
