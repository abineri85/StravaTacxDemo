﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using StravaServices.Logic.ApiClient;
using StraveServices.Helpers;

namespace StraveServices.Controllers
{
    [EnableCors("AllowAll")]
    [Route("api/authentication")]
    [ApiController]
    public class AuthenticationController : Controller
    {
        IStravaSessionHelper _stravaSessionHelper;

        IConfiguration _config;

        public AuthenticationController(IStravaSessionHelper stravaSessionHelper, IConfiguration config)
        {
            _stravaSessionHelper = stravaSessionHelper;
            _config = config;
        }

        [EnableCors("AllowAll")]
        [HttpGet]
        [Route("exchange_token")]
        public IActionResult ExchangeToken(string code)
        {
            // handle redirect after authentication
            _stravaSessionHelper.Authenticate(code);
            var targetUrl = _config.GetValue<string>("Strava:PostLoginUrl");         
            HttpContext.Response.Headers.Add("Access-Control-Allow-Origin", "*");

           
            return Redirect(targetUrl);
        }

    }
}