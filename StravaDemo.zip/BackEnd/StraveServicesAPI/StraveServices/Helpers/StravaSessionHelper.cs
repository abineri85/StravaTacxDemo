﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using StravaServices.Logic.ApiClient;

namespace StraveServices.Helpers
{
    public class StravaSessionHelper : IStravaSessionHelper
    {
        private string _baseUrl;

        private string _clientSecret;

        private string _clientId;

        private IHttpContextAccessor _httpContextAccessor;

        const string SessionTokenKey = "Strava.Token";

        public StravaSessionHelper(IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
            _baseUrl = config.GetValue<string>("Strava:BaseUrl");
            _clientId = config.GetValue<string>("Strava:ClientId");
            _clientSecret = config.GetValue<string>("Strava:ClientSecret");
            _httpContextAccessor = httpContextAccessor;
        }
        // authentication
        public void Authenticate(string code)
        {
            using (var apiClient = new StravaApiClient(_baseUrl, _clientSecret, _clientId))
            {
                var token = apiClient.GetToken(code);
                _httpContextAccessor.HttpContext.Session.SetString(SessionTokenKey, token);
            }
        }
        // check if user is authenticated
        public StravaApiClient GetAuthenticatedApiClient()
        {
            var token = GetToken();
            if (string.IsNullOrWhiteSpace(token))
            {   
                throw new Exception("Not authenticated");
            }

            var result = new StravaApiClient(_baseUrl, _clientSecret, _clientId, token);
            return result;
        }

       

        private string GetToken()
        {
            var session = _httpContextAccessor.HttpContext.Session;
            if (session?.Keys == null || !session.Keys.Contains(SessionTokenKey))
            {
                return null;
            }

            var result = session.GetString(SessionTokenKey);
            return result;
        }

        public bool IsAuthenticated() => !string.IsNullOrWhiteSpace(GetToken());
    }
}
