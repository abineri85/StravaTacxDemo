﻿using StravaServices.Logic.ApiClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StraveServices.Helpers
{
    public interface IStravaSessionHelper
    {
        void Authenticate(string code);

        bool IsAuthenticated();

        StravaApiClient GetAuthenticatedApiClient();
    }
}
