﻿using StraveServices.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StraveServices.Helpers
{
    public class CalculationHelper : ICalculationHelper
    {

        public float? Average(List<float?> numbers)
        {
            return numbers.Average();
        }

        public List<Stats> PerformCalculations(List<ActivitiesModel> data)
        {
            var stats = new List<Stats>();
            var maxSpeeds = data.Select(x => x.max_speed).ToList();
            var distances = data.Select(x => x.distance).ToList();
            var timesTotal = data.Select(x => (float?)x.elapsed_time).ToList();
            // Perhaps do a lookup of somekind instead of the strings
            stats.Add(new Stats() {Stat = Average(maxSpeeds), Name = "Average Speed"});
            stats.Add(new Stats() { Stat = Total(distances), Name= "Total Distance"});
            stats.Add(new Stats() { Stat = Total(timesTotal), Name = "Total Time" });


            return stats;
        }

        public float? Total(List<float?> numbers)
        {
            return numbers.Sum();
        }
    }
}
