﻿using StraveServices.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StraveServices.Helpers
{
    public interface ICalculationHelper
    {
        List<Stats> PerformCalculations(List<ActivitiesModel> data);
        float? Average(List<float?> numbers);
        float? Total(List<float?> numbers);

    }
}
