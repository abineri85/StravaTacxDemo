﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StraveServices.Models
{
    public class Stats
    {
        public float? Stat { get; set; }
        public string Name { get; set; }
        
    }
}
