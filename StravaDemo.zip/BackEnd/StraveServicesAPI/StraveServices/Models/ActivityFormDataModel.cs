﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StraveServices.Models
{
    public class ActivityFormDataModel
    {
        // This data transfer object is a paste special using vs. It not following convention (not capitals etc)
        // With more time this could typed properly or using the [JsonProperty(PropertyName = "prop name")]
        public string activityType { get; set; }
        public string description { get; set; }
        public string distance { get; set; }
        public string elaspeTime { get; set; }
        public string name { get; set; }
        public string startDate { get; set; }
    }
}
