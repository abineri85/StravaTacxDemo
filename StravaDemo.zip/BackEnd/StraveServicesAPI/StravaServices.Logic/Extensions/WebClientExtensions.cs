﻿using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace StravaServices.Logic.Extensions
{
    public static class WebClientExtensions
    {
        // using generics to make calls
        public static T HttpGet<T>(this WebClient webClient, string hostAndPath, Dictionary<string, string> queryStringParameters)
        {
            var url = QueryHelpers.AddQueryString(hostAndPath, queryStringParameters);
            var stringResponse = webClient.DownloadString(url);
            var result = JsonConvert.DeserializeObject<T>(stringResponse);
            return result;
        }

        public static T HttpGet<T>(this WebClient webClient, string url)
        {
            var stringResponse = webClient.DownloadString(url);
            var result = JsonConvert.DeserializeObject<T>(stringResponse);
            return result;
        }

        public static T HttpPost<T>(this WebClient webClient, string hostAndPath, Dictionary<string, string> queryStringParameters)
        {
            var url = QueryHelpers.AddQueryString(hostAndPath, queryStringParameters);
            var stringResponse = webClient.UploadString(url, string.Empty);
            var result = JsonConvert.DeserializeObject<T>(stringResponse);
            return result;
        }
    }
}
