﻿using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using StravaServices.Logic.Extensions;
using System.Net;
using System.Text;
using StravaServices.Logic.ApiClient.Dto;
using StraveServices.Models;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;

namespace StravaServices.Logic.ApiClient
{
    public class StravaApiClient : IDisposable
    {
        private string _baseUrl;

        private string _clientSecret;

        private string _clientId;

        private string _token;

        private WebClient _webClient = new WebClient();

        public StravaApiClient(string baseUrl, string clientSecret, string clientId)
        {
            _baseUrl = baseUrl;
            _clientSecret = clientSecret;
            _clientId = clientId;
        }
        // creates authenticated client for calls
        public StravaApiClient(string baseUrl, string clientSecret, string clientId, string token)
            : this(baseUrl, clientSecret, clientId)
        {
            _token = token;
            _webClient.Headers.Add($"Authorization: Bearer {_token}");
        }

        // get temperorary token
        public string GetToken(string code, string grantType = "authorization_code")
        {
            var apiResponse = _webClient.HttpPost<OAuthResponse>($"{_baseUrl}/oauth/token" ,  new Dictionary<string, string>  {
                { "client_id", _clientId},
                { "client_secret", _clientSecret },
                {"code", code },
                { "grant_type", grantType }
            });

            return apiResponse.AccessToken;
        }

        public List<ActivitiesModel> GetActivities()
        {
            if (string.IsNullOrWhiteSpace(_token))
            {
                throw new Exception("Not authenticated");
            }
            var result = _webClient.HttpGet<List<ActivitiesModel>>($"{_baseUrl}/api/v3/athlete/activities");
            return result;
        }

        
        public bool UploadFile(Stream fileStream, string fileName)
        {
            try
            {
                string url = $"{_baseUrl}/api/v3/uploads";

                string extension = Path.GetExtension(fileName).Trim('.');
                var client = new HttpClient();
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {_token}");

                // this is not ideal, due to time restraints the request is built here this way.
                // ideal more needs to be done find out what does and does not need to be here.
                // perhaps create a seperate header method
                using (var streamContent = new StreamContent(fileStream))
                {
                    streamContent.Headers.ContentDisposition = new ContentDispositionHeaderValue("form-data");
                    streamContent.Headers.ContentDisposition.Name = "\"file\"";
                    streamContent.Headers.ContentDisposition.FileName = "\"" + fileName + "\"";
                    streamContent.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                    string boundary = Guid.NewGuid().ToString();
                    var content = new MultipartFormDataContent(boundary);
                    content.Headers.Remove("Content-Type");
                    content.Headers.TryAddWithoutValidation("Content-Type", "multipart/form-data; boundary=" + boundary);
                    content.Add(streamContent);
                    content.Add(new StringContent(extension), String.Format("\"{0}\"", "data_type"));
                   
                    var response = client.PostAsync(url, content).Result;
                    response.EnsureSuccessStatusCode();
                   
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
                
        }


        // manually dispose using this method. Close connections etc
        public void Dispose()
        {
            _webClient.Dispose();
        }
    }
}
