﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StravaServices.Logic.ApiClient.Dto
{
    public class Athlete
    {
        // This data transfer object is a paste special using vs. It not following convention (not capitals etc)
        // With more time this could typed properly or using the [JsonProperty(PropertyName = "prop name")]
        public int id { get; set; }
        public object username { get; set; }
        public int resource_state { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string country { get; set; }
        public string sex { get; set; }
        public bool premium { get; set; }
        public bool summit { get; set; }
        public DateTime created_at { get; set; }
        public DateTime updated_at { get; set; }
        public int badge_type_id { get; set; }
        public string profile_medium { get; set; }
        public string profile { get; set; }
        public object friend { get; set; }
        public object follower { get; set; }
    }
}
