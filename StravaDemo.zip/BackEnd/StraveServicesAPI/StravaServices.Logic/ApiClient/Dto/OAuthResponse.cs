﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace StravaServices.Logic.ApiClient.Dto
{
    class OAuthResponse
    {
        public string token_type { get; set; }
        public int expires_at { get; set; }
        public int expires_in { get; set; }
        public string refresh_token { get; set; }
        // mapping for proper coding standards. With more time this would be applied to all properties across all files.
        [JsonProperty(PropertyName = "access_token")]
        public string AccessToken { get; set; }
        public Athlete athlete { get; set; }
    }
}

