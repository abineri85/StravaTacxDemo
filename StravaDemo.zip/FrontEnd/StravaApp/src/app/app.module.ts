import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { CreateActivityComponent } from './create-activity/create-activity.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MatExpansionModule } from '@angular/material/expansion';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DisplayActivitiesComponent } from './display-activities/display-activities.component';
import { MatTableModule } from '@angular/material/table';
import { MatCheckboxModule } from '@angular/Material';

@NgModule({
  declarations: [
    AppComponent,
    FileUploadComponent,
    CreateActivityComponent,
    DisplayActivitiesComponent
  ],
  exports:[
    MatExpansionModule,
    MatTableModule,
    MatCheckboxModule
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    MatExpansionModule,
    MatTableModule,
    ReactiveFormsModule,
    MatCheckboxModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
