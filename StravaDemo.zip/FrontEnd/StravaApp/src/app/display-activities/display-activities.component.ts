import { Component, OnInit } from '@angular/core';
import { HttpRequest, HttpClient, HttpEventType, HttpHeaders  } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { SelectionModel } from '@angular/cdk/collections';
import { DisplayActivities } from './display-activities.model';


let ELEMENT_DATA: ActivityInfo[] = [];
let StatTypes: any[] =[];

export interface ActivityInfo {
  name: string;
  id: number;  
}

@Component({
  selector: 'display-activities',
  templateUrl: './display-activities.component.html',
  styleUrls: ['./display-activities.component.css']
})
export class DisplayActivitiesComponent implements OnInit {
  public myDataArray:any;
  displayedColumns: string[] = ['Activity ID', 'Activity Name'];
  dataSource:any;
  statisticType:any;
  private API_URL= environment.API_URL;
  private result:any;
  public readySubmit: boolean = true;
  public activityData: any[] = [];
  public statTypes: any[] = [];
  public hasStats:boolean;
 
  constructor(private http: HttpClient) { }

  ngOnInit() {
    
  }

  getActivities(){
    const uploadReq = new HttpRequest('GET', this.API_URL+'/api/GetAllActivities', {withCredentials: true} );

    this.http.request(uploadReq).subscribe(event => {
      this.result = event;
      
      if(this.result.body){  
        this.mapActivitiesForTable(this.result.body.activities);   
        this.mapStatsForTable(this.result.body.stats);
      }
    });
  }

  mapActivitiesForTable(data: any)
  {
    data.forEach(element => {
      ELEMENT_DATA.push({id: element.id, name:element.name});
    });
    
    this.dataSource = ELEMENT_DATA;
    

    this.readySubmit = false;
  }

  mapStatsForTable(data:any){
    data.forEach(element => {
      StatTypes.push({name:element.name, value:element.stat});
    });

    this.statisticType = StatTypes;
  }

 

}
