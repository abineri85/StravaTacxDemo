

export class DisplayActivities{

    public id: number;
    public name: string;
}