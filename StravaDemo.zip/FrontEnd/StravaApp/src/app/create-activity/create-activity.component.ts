import { Component, OnInit } from '@angular/core';
import {MatExpansionModule} from '@angular/material/expansion';
import { FormBuilder, FormGroup, FormsModule, FormControl, Validators } from '@angular/forms';
import { HttpRequest, HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
//import { HttpClient } from 'selenium-webdriver/http';



@Component({
  selector: 'create-activity',
  templateUrl: './create-activity.component.html',
  styleUrls: ['./create-activity.component.css']
})
export class CreateActivityComponent implements OnInit {
 
  notValid:boolean;
  notValidDate:boolean;
  private API_URL= environment.API_URL;
  constructor(private fb: FormBuilder,private http: HttpClient) {    
  }

  ngOnInit() {
   
  }

  submitForm(data)
  {
    this.notValid = false;
    this.notValidDate = false;
    //!data.name && !data.activityType && !data.startDate && !data.elaspeTime
    if(!data.name || !data.activityType || !data.startDate || !data.elaspeTime)
    {      
      this.notValid = true;
      return;
    }

    if(!this.dateValidator(data.startDate)){
      this.notValidDate = true;
      return;
    }

    const uploadReq = new HttpRequest('POST', this.API_URL+`/api/CreateActivity`, data, {
      
    });

    this.http.request(uploadReq).subscribe(event => {
      var res = event;
    });
  }

  dateValidator(str) {
  
    if (!/^\d{2}\/\d{2}\/\d{4}$/.test(str)) {
      return false
    }else{
      return true;
    }
  }

 

}
