import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpRequest, HttpEventType, HttpResponse, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Component({
  selector: 'file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {

  public progress: number;
  public errorMessage: string;
  public uploading:boolean;
  public uploadSuccessful: boolean;
  public uploadFailure: boolean;
  public result : any;

  private API_URL= environment.API_URL;

  constructor(private http: HttpClient) { }

  ngOnInit() {
  }

  upload(files)
  {
    this.uploading = true;
    this.uploadSuccessful = false;
    this.uploadFailure = false;

    if (files.length === 0)
      return;

    const formData = new FormData();

    for (let file of files)
      formData.append(file.name, file);
   
    const uploadReq = new HttpRequest('POST', this.API_URL+`/api/UploadActivity`, formData, {withCredentials: true} );
    

    this.http.request(uploadReq).subscribe(event => {     
      {responseType: 'text'}
      this.result = event;      
      if(this.result.body)
      {
        if(this.result.body.isSuccess)
        {
          this.uploadSuccessful = true;
          this.uploading = false;
        }else{
          this.uploadFailure =  true;
          this.uploading = false;
          this.errorMessage = this.result.body.errorMessage;
        }
      }
    });  

  }

}
